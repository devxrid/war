import logging
from logging import handlers
import supplier.ean.update_context_overall as overall

# ====================================================================================================================
# log settings
# ====================================================================================================================
slogFormatter = logging.Formatter('%(asctime)s,%(message)s')
# handler settings
slogHandler = handlers.TimedRotatingFileHandler(filename='./log/ean_static.log', when='midnight', interval=1,
                                                encoding='utf-8')

slogHandler.setFormatter(slogFormatter)
slogHandler.suffix = "%Y%m%d"
# logger set
slog = logging.getLogger()
slog.setLevel(logging.INFO)
slog.addHandler(slogHandler)


# ====================================================================================================================


# 익스피디아 콘텐츠 업데이트
def ean_contents_update():
    language = 'en-US'
    hotel = False
    themes = False
    guest = False
    ht_desc = False
    ht_images = False
    ht_attrs = False
    ht_amens = False
    room = True
    rm_amens = False
    rm_images = False

    try:
        params = {
            'language': language,
            'hotel': hotel,
            'themes': themes,
            'guest': guest,
            'ht_desc': ht_desc,
            'ht_images': ht_images,
            'ht_attrs': ht_attrs,
            'ht_amens': ht_amens,
            'room': room,
            'rm_amens': rm_amens,
            'rm_images': rm_images,
            'linked': ''
        }

        # if param_data['property_ids'] != '':
        #     params['property_ids'] = param_data['property_ids']
        #
        # if param_data['date_updated_start'] != '':
        #     params['date_updated_start'] = param_data['date_updated_start']

        more_result = True
        linked = ''
        result = {

        }

        slog.info(params)

        while more_result:
            result = overall.updateContent(params)
            if len(result['moreLink']) == 0:
                more_result = False
            else:
                more_result = True
                print("next link: ", result['moreLink'])
                params['linked'] = result['moreLink']

        return params
    except Exception as e:
        print(e)
        return {
            'status': 'error',
            'error': str(e)
        }


if __name__ == '__main__':
    ean_contents_update()
