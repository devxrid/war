# 스케줄 종류에는 여러가지가 있는데 대표적으로 BlockingScheduler, BackgroundScheduler 입니다
# BlockingScheduler 는 단일수행에, BackgroundScheduler은 다수 수행에 사용됩니다.
# 여기서는 BackgroundScheduler 를 사용하겠습니다.
from apscheduler.schedulers.background import BackgroundScheduler
import time
import common.utils as utils
import supplier.ean.update_context_overall as overall


# 익스피디아 영문 콘텐츠 업데이트
def ean_content_update_job_en():
    print("ean contents update .... start", str(time.localtime().tm_hour)
          + ":" + str(time.localtime().tm_min) + ":"
          + str(time.localtime().tm_sec))
    try:
        language = 'ko-KR'

        # days, hours, weeks, months, years
        # days=1 : 1일전
        # 현재 기준 한달전 이 후 업데이트된 시설목록 가져온다.
        date_updated_start = datetime.datetime.now() - datetime.timedelta(months=1)
        # property_ids = [15031]

        params = {
            'language': 'en-US',
            'date_updated_start': date_updated_start,
            'hotel': True,
            'themes': True,
            'guest': True,
            'ht_desc': True,
            'ht_images': True,
            'ht_attrs': True,
            'ht_amens': True,
            'room': True,
            'rm_amens': True,
            'rm_images': True,
            'linked': ''
        }

        more_result = True
        linked = ''
        result = {

        }

        print("req : ", params)

        while more_result:
            result = overall.updateContent(params)
            if len(result['moreLink']) == 0:
                more_result = False
            else:
                more_result = True
                print("next link: ", result['moreLink'])
                params['linked'] = result['moreLink']

        print("ean contents update .... end", str(time.localtime().tm_hour)
              + ":" + str(time.localtime().tm_min) + ":"
              + str(time.localtime().tm_sec))
    except Exception as e:
        print(e)
        return {
            'status': 'error',
            'error': str(e)
        }


# 익스피디아 한글 콘텐트 업데이트
def ean_content_update_job_kr():
    print("ean contents update .... start", str(time.localtime().tm_hour)
          + ":" + str(time.localtime().tm_min) + ":"
          + str(time.localtime().tm_sec))
    try:
        language = 'ko-KR'

        # days, hours, weeks, months, years
        # days=1 : 1일전
        # 현재 기준 한달전 이 후 업데이트된 시설목록 가져온다.
        date_updated_start = datetime.datetime.now() - datetime.timedelta(months=1)
        # property_ids = [15031]

        params = {
            'language': 'ko-KR',
            'date_updated_start': date_updated_start,
            'hotel': True,
            'themes': True,
            'guest': True,
            'ht_desc': True,
            'ht_images': True,
            'ht_attrs': True,
            'ht_amens': True,
            'room': True,
            'rm_amens': True,
            'rm_images': True,
            'linked': ''
        }

        more_result = True
        linked = ''
        result = {

        }

        print("req : ", params)

        while more_result:
            result = overall.updateContent(params)
            if len(result['moreLink']) == 0:
                more_result = False
            else:
                more_result = True
                print("next link: ", result['moreLink'])
                params['linked'] = result['moreLink']

        print("ean contents update .... end", str(time.localtime().tm_hour)
              + ":" + str(time.localtime().tm_min) + ":"
              + str(time.localtime().tm_sec))
    except Exception as e:
        print(e)
        return {
            'status': 'error',
            'error': str(e)
        }


# BackgroundScheduler 를 사용하면 stat를 먼저 하고 add_job 을 이용해 수행할 것을 등록해줍니다.
sched = BackgroundScheduler()
sched.start()

# 매일 12시 30분에 실행
# @sched.scheduled_job('interval', seconds=5, id='test_1')
# sched.add_job(ean_content_update_job, 'cron', seconds=5, id="job_01")

# 이런식으로 추가도 가능. 매분에 실행
# sched.add_job(ean_content_update_job, 'cron', second='0', id="job_01")

# 매일 [9시15분, 9시45분, 15시15분, 15시45분]에 실행
# sched.add_job(ean_content_update_job, 'cron', hour='9,15', minute='15,45', id="job_01")

# 매주 x요일 x시 x분에 실행한다는 의미.
sched.add_job(ean_content_update_job_en, 'cron', day_of_week='sun', hour='0', minute="10", id="job_en")
sched.add_job(ean_content_update_job_kr, 'cron', day_of_week='sun', hour='0', minute="15", id="job_kr")

print("TourKhan batch (EPS Rapid 2.4 properties concent) running...")
count = 0
while True:
    time.sleep(1)
