def noneToBlank(self):
    if self is None:
        return ''
    else:
        return self


def noneToBool(self):
    if self is None:
        return False


def isHaveToTrue(self):
    if noneToBlank(self.id) != '':
        return True
    else:
        return False


def qouteConvert(self):
    return self.replace("'", "''")
