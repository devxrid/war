from setuptools import setup

setup(
    name='rapid',
    version='1.0.0',
    packages=[''],
    url='',
    license='',
    author='',
    author_email='',
    description=''
)
