import common.utils as utils

# ===========================================================================
# 호텔콘텐츠 JSON Parser
# ===========================================================================

# 호텔 기본정보
def parserHotelBase(property_data):
    property_id = property_data['property_id']

    # 호텔 기본정보 생성
    property_nm = property_data['name']

    category_id = ''
    category_nm = ''
    if 'category' in property_data.keys():
        category_data = property_data['category']
        if 'id' in category_data.keys():
            category_id = category_data['id']
        if 'name' in category_data.keys():
            category_nm = category_data['name']

    country_code = ''
    city = ''
    postal_code = ''
    address = ''
    state_province_cd = ''
    state_province_nm = ''
    if 'address' in property_data.keys():
        address_data = property_data['address']
        if 'country_code' in address_data.keys():
            country_code = address_data['country_code']
        if 'city' in address_data.keys():
            city = address_data['city']
        if 'postal_code' in address_data.keys():
            postal_code = address_data['postal_code']
        if 'line_1' in address_data.keys():
            address = address_data['line_1']
        if 'state_province_code' in address_data.keys():
            state_province_cd = address_data['state_province_code']
        if 'state_province_name' in address_data.keys():
            state_province_nm = address_data['state_province_name']

    begin_time = ''
    end_time = ''
    instructions = ''
    special_instructions = ''
    min_age = ''
    if 'checkin' in property_data.keys():
        checkin_data = property_data['checkin']
        if 'begin_time' in checkin_data.keys():
            begin_time = checkin_data['begin_time']
        if 'end_time' in checkin_data.keys():
            end_time = checkin_data['end_time']
        if 'instructions' in checkin_data.keys():
            instructions = checkin_data['instructions']
        if 'special_instructions' in checkin_data.keys():
            special_instructions = checkin_data['special_instructions']
        if 'min_age' in checkin_data.keys():
            min_age = checkin_data['min_age']
    phone = ''
    fax = ''
    if 'phone' in property_data.keys():
        phone = property_data['phone']
    if 'fax' in property_data.keys():
        fax = property_data['fax']
    if 'location' in property_data.keys():
        location_data = property_data['location']
        if 'coordinates' in location_data.keys():
            coordinates_data = location_data['coordinates']
            if 'latitude' in coordinates_data.keys():
                latitude = coordinates_data['latitude']
            if 'longitude' in coordinates_data.keys():
                longitude = coordinates_data['longitude']
    rank = ''
    if 'rank' in property_data.keys():
        rank = property_data['rank']
    rating = ''
    type = ''
    if 'ratings' in property_data.keys():
        ratings_data = property_data['ratings']
        if 'property' in ratings_data.keys():
            ratings_property_data = ratings_data['property']
            if 'rating' in ratings_property_data.keys():
                rating = ratings_property_data['rating']
            if 'type' in ratings_property_data.keys():
                type = ratings_property_data['type']

    data = {
        'property_id': property_id,
        'property_nm': property_nm.replace("'", "''"),
        'category_id': category_id,
        'category_nm': category_nm,
        'country_cd': country_code,
        'city': city,
        'postal_cd': postal_code,
        'address': address,
        'checkin_stime': begin_time,
        'checkin_etime': end_time,
        'checkin_min_age': min_age,
        'checkin_instructions': instructions.replace("'", "''"),
        'checkin_special_instructions': special_instructions.replace("'", "''"),
        'phone': phone,
        'fax': fax,
        'lat': latitude,
        'lon': longitude,
        'rank': rank,
        'rating_type': type,
        'rating_val': rating,
        'state_province_cd': state_province_cd,
        'state_province_nm': state_province_nm
    }

    return data


# 호텔 테마
def parserHotelTheme(property_data):
    print(">>> parsing base hotel theme...")
    property_id = property_data['property_id']

    datas = list()
    if 'themes' in property_data.keys():
        themes = property_data['themes']
        for key in themes.keys():
            themeJson = themes[key]
            theme_id = themeJson['id']
            theme_nm = themeJson['name']

            data = {
                'property_id': property_id,
                'theme_id': theme_id,
                'theme_nm': theme_nm
            }
            datas.append(data)

    return datas


# 호텔 설명
def parserHotelDesc(property_data):
    print(">>> parsing base hotel description...")
    property_id = property_data['property_id']

    headline = ''
    amenities = ''
    dining = ''
    business_amenities = ''
    rooms = ''
    attractions = ''
    location = ''
    renovations = ''
    if 'descriptions' in property_data.keys():
        desc_data = property_data['descriptions']
        if 'headline' in desc_data.keys():
            headline = desc_data['headline']
        if 'amenities' in desc_data.keys():
            amenities = desc_data['amenities']
        if 'dining' in desc_data.keys():
            dining = desc_data['dining']
        if 'business_amenities' in desc_data.keys():
            business_amenities = desc_data['business_amenities']
        if 'rooms' in desc_data.keys():
            rooms = desc_data['rooms']
        if 'attractions' in desc_data.keys():
            attractions = desc_data['attractions']
        if 'location' in desc_data.keys():
            location = desc_data['location']
        if 'renovations' in desc_data.keys():
            renovations = desc_data['renovations']

    know_before_you_go = ''
    if 'policies' in property_data.keys():
        policies_data = property_data['policies']
        if 'know_before_you_go' in policies_data.keys():
            know_before_you_go = policies_data['know_before_you_go']

    fees_mandatory = ''
    fees_option = ''
    if 'fees' in property_data.keys():
        fees_Data = property_data['fees']
        if 'mandatory' in fees_Data.keys():
            fees_mandatory = fees_Data['mandatory']
        if 'optional' in fees_Data.keys():
            fees_option = fees_Data['optional']

    data = {
        'property_id': property_id,
        'headline': headline,
        'amenities': amenities,
        'dining': dining,
        'business_amenities': business_amenities,
        'rooms': rooms,
        'attractions': attractions,
        'location': location,
        'renovations': renovations,
        'know_before_you_go': know_before_you_go,
        'fees_mandatory': fees_mandatory,
        'fees_option': fees_option
    }
    return data


# 호텔 고객평점 정보
# -------------------------------------------------------------------------------------------------
# count:            현재 이 숙박 시설에 대해 이용 가능한 고객 이용 후기의 전체 평점 개수입니다.
# overall:          전체 고객 이용 후기로부터 평균을 낸 숙박 시설의 전체 평점입니다. 1.0~5.0의 값을 반환합니다.
# cleanliness:      전체 고객 이용 후기로부터 평균을 낸 숙박 시설의 청결도 평점입니다. 1.0~5.0의 값을 반환합니다.
# service:          전체 고객 이용 후기로부터 평균을 낸 숙박 시설의 직원 서비스 평점입니다. 1.0~5.0의 값을 반환합니다.
# comfort:          전체 고객 이용 후기로부터 평균을 낸 숙박 시설의 안락함 평점입니다. 1.0~5.0의 값을 반환합니다.
# condition:        전체 고객 이용 후기로부터 평균을 낸 숙박 시설의 상태 평점입니다. 1.0~5.0의 값을 반환합니다.
# location:         전체 고객 이용 후기로부터 평균을 낸 숙박 시설의 접근 편리성 평점입니다. 1.0~5.0의 값을 반환합니다.
# neighborhood:     전체 고객 이용 후기로부터 평균을 낸 숙박 시설의 주변 환경 평점입니다. 1.0~5.0의 값을 반환합니다.
# quality:          전체 고객 이용 후기로부터 평균을 낸 숙박 시설의 객실 품질 평점입니다. 1.0~5.0의 값을 반환합니다.
# value:            전체 고객 이용 후기로부터 평균을 낸 숙박 시설의 가격 대비 만족도 평점입니다. 1.0~5.0의 값을 반환합니다.
# amenities:        전체 고객 이용 후기로부터 평균을 낸 숙박 시설의 편의 시설 평점입니다. 1.0~5.0의 값을 반환합니다.
# recom_percent:    이 숙박 시설에서의 숙박을 추천한 고객의 비율입니다.
def parserHotelGuest(property_data):
    print(">>> parsing base hotel guest rating...")
    property_id = property_data['property_id']
    datas = list()

    data = {
        'property_id': property_id,
        'count': '',
        'overall': '',
        'cleanliness': '',
        'service': '',
        'comfort': '',
        'condition': '',
        'location': '',
        'neighborhood': '',
        'quality': '',
        'value': '',
        'amenities': '',
        'recom_percent': ''
    }

    if 'ratings' in property_data.keys():
        ratings_data = property_data['ratings']
        if 'guest' in ratings_data.keys():
            guest_data = ratings_data['guest']

            if 'count' in guest_data.keys():
                data['count'] = str(guest_data['count'])
            if 'overall' in guest_data.keys():
                data['overall'] = str(guest_data['overall'])
            if 'cleanliness' in guest_data.keys():
                data['cleanliness'] = str(guest_data['cleanliness'])
            if 'service' in guest_data.keys():
                data['service'] = str(guest_data['service'])
            if 'comfort' in guest_data.keys():
                data['comfort'] = str(guest_data['comfort'])
            if 'condition' in guest_data.keys():
                data['condition'] = str(guest_data['condition'])
            if 'location' in guest_data.keys():
                data['location'] = str(guest_data['location'])
            if 'neighborhood' in guest_data.keys():
                data['neighborhood'] = str(guest_data['neighborhood'])
            if 'quality' in guest_data.keys():
                data['quality'] = str(guest_data['quality'])
            if 'value' in guest_data.keys():
                data['value'] = str(guest_data['value'])
            if 'amenities' in guest_data.keys():
                data['amenities'] = str(guest_data['amenities'])
            if 'recommendation_percent' in guest_data.keys():
                data['recom_percent'] = str(guest_data['recommendation_percent'])

    return data


# 호텔 부대시설정보
def parserHotelAttr(property_data):
    print(">>> parsing base hotel attribute...")
    property_id = property_data['property_id']
    datas = list()
    if 'attributes' in property_data.keys():
        attribute_data = property_data['attributes']
        attr_gbn = ""
        if 'pets' in attribute_data.keys():
            attr_gbn = "pet"
            pets_data = attribute_data['pets']
            for key in pets_data.keys():
                pets_args = pets_data[key]
                attr_id = pets_args['id']
                attr_nm = pets_args['name']
                attr_val = ""
                data = {
                    'property_id': property_id,
                    'attribute_gbn': 'pet',
                    'attribute_id': attr_id,
                    'attribute_nm': attr_nm,
                    'attribute_val': attr_val
                }
                datas.append(data)
        if 'general' in attribute_data.keys():
            attr_gbn = "gen"
            genr_data = attribute_data['general']
            for key in genr_data.keys():
                genr_args = genr_data[key]
                attr_id = genr_args['id']
                attr_nm = genr_args['name']
                attr_val = ""
                data = {
                    'property_id': property_id,
                    'attribute_gbn': 'gen',
                    'attribute_id': attr_id,
                    'attribute_nm': attr_nm,
                    'attribute_val': attr_val
                }
                datas.append(data)
    return datas


# 호텔 편의시설
def parserHotelAmen(property_data):
    print(">>> parsing base hotel amenity...")
    property_id = property_data['property_id']
    datas = list()
    if 'amenities' in property_data.keys():
        amenity_data = property_data['amenities']
        for key in amenity_data.keys():
            amenity_info = amenity_data[key]
            amenity_id = amenity_info['id']
            amenity_nm = amenity_info['name']
            data = {
                'property_id': property_id,
                'amenity_id': amenity_id,
                'amenity_nm': amenity_nm,
                'amenity_val': ""
            }
            datas.append(data)
    return datas


# 호텔이미지
def parserHotelImage(property_data):
    print(">>> parsing base hotel image...")
    property_id = property_data['property_id']
    images = list()
    try:
        if 'images' in property_data.keys():
            iseq = 1
            for image_data in property_data['images']:
                img_seq = str(iseq)
                category_id = image_data['category']

                hero = "N"
                if image_data['hero_image']:
                    hero = "Y"

                href_70 = ""
                href_350 = ""
                href_1000 = ""

                links = image_data['links']
                for key in links.keys():
                    links_data = links[key]

                    if key == "350px":
                        href_350 = links_data['href']
                    if key == "70px":
                        href_70 = links_data['href']
                    if key == "1000px":
                        href_1000 = links_data['href']

                data = {
                    'property_id': property_id,
                    'img_seq': iseq,
                    'category_id': category_id,
                    'hero': hero,
                    'href_70': href_70,
                    'href_350': href_350,
                    'href_1000': href_1000
                }
                images.append(data)
                iseq += 1
    except Exception as e:
        print("SEQ : " + iseq, e)

    return images


# 객식설명
desc = ''
def parserRoomBase(property_data):
    global desc
    # print(">>> parsing base room description...")
    property_id = property_data['property_id']
    datas = list()
    if 'rooms' in property_data.keys():
        room_data = property_data['rooms']
        for key in room_data.keys():
            room_info = room_data[key]
            room_id = room_info['id']
            if 'descriptions' in room_info.keys():
                room_desc_data = room_info['descriptions']
                desc = room_desc_data['overview']
                desc = desc.replace("'", "''")

            data = {
                'property_id': property_id,
                'room_id': room_id,
                'desc': desc
            }
            datas.append(data)
    return datas


# 객실편의시설
def parserRoomAmeni(property_data):
    print(">>> parsing base room amenity...")
    property_id = property_data['property_id']
    datas = list()
    if 'rooms' in property_data.keys():
        room_data = property_data['rooms']
        for key in room_data.keys():
            room_info = room_data[key]
            room_id = room_info['id']
            if 'amenities' in room_info.keys():
                ameni_data = room_info['amenities']
                for key1 in ameni_data.keys():
                    ameni_info = ameni_data[key1]
                    amenity_id = ameni_info['id']
                    amenity_nm = ameni_info['name']
                    amenity_nm = amenity_nm.replace("'", "''")
                    amenity_val = ""

                    data = {
                        'property_id': property_id,
                        'room_id': room_id,
                        'amenity_id': amenity_id,
                        'amenity_nm': amenity_nm,
                        'amenity_val': ""
                    }
                    datas.append(data)
    return datas


# 객실이미지정보
def parserRoomImage(property_data):
    print(">>> parsing base room image...")
    property_id = property_data['property_id']
    images = list()
    if 'rooms' in property_data.keys():
        room_data = property_data['rooms']
        for key in room_data.keys():
            room_info = room_data[key]
            room_id = room_info['id']
            if 'images' in room_info.keys():
                images = list()
                iseq = 1
                for image_data in room_info['images']:
                    img_seq = str(iseq)
                    category_id = image_data['category']

                    hero = "N"
                    if image_data['hero_image']:
                        hero = "Y"

                    href_70 = ""
                    href_200 = ""
                    href_350 = ""
                    href_1000 = ""

                    links = image_data['links']
                    for key in links.keys():
                        links_data = links[key]

                        if key == "70px":
                            href_70 = links_data['href']
                        if key == "200px":
                            href_200 = links_data['href']
                        if key == "350px":
                            href_350 = links_data['href']
                        if key == "1000px":
                            href_1000 = links_data['href']

                    data = {
                        'property_id': property_id,
                        'room_id': room_id,
                        'img_seq': iseq,
                        'category_id': category_id,
                        'hero': hero,
                        'href_70': href_70,
                        'href_200': href_200,
                        'href_350': href_350,
                        'href_1000': href_1000
                    }
                    images.append(data)
                    iseq += 1
    return images
