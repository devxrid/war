# =============================================================
# 특정 property_id 에 대한 콘텐츠 목록을 조회한다.
# =============================================================

import mysql.connector
import json
import requests
import common.utils as utils
import supplier.ean.ean_auth as ean
import supplier.ean.exec_data as ed
import supplier.ean.parser_property as pp
import supplier.ean.exec_result as ers

rows = list()


# jdbc:mariadb://1.234.40.180:3306/tassdb
def processExecute(property_json, work_gbn):
    global rows
    print(">>> parsing prcessing...")

    # DB 연결 설정
    conn = mysql.connector.connect(
        host='1.234.40.180',
        user='tasssys',
        passwd='tasssys2019',
        database='tassdb'
    )

    cursor = conn.cursor(dictionary=True)

    query = "SELECT distinct property_id FROM ean_room_en"

    try:
        cursor.execute(query)
        rows = cursor.fetchall()
    except Exception as e:
        print(e)

    # print(len(rows))

    # for key in property_json.keys():

    language = work_gbn['language']
    # ================================================
    # 추가/수정 대상 목록 정의
    # ================================================
    hotels = list()  # 호텔 기본정보
    themes = list()  # 호텔 테마
    hotelGuests = list()  # 호텔 설명정보
    hotelDescs = list()  # 호텔 설명정보
    hotelAttrs = list()  # 호텔 부대시설정보
    hotelAmens = list()  # 호텔 편의시설정보
    hotelImages = list()  # 호텔 이미지정보
    roomBases = list()  # 객실 정보
    roomAmenis = list()  # 객실 편의시설정보
    roomImages = list()  # 객실 이미지정보

    count = 0
    for key in property_json.keys():

        property_data = property_json[key]

        property_id = property_data['property_id']

        isRun = False
        for row in rows:
            if property_id == row['property_id']:
                isRun = True
                break

        if isRun:
            # print(str(property_id) + ' Break process ')
            continue

        # print(property_data)
        print(property_id + ' ' + property_data['name'])

        # 호텔기본정보
        if work_gbn['hotel']:
            hotelBase = pp.parserHotelBase(property_data)
            hotels.append(hotelBase)

        # 호텔테마
        if work_gbn['themes']:
            temps = pp.parserHotelTheme(property_data)
            for theme in temps:
                themes.append(theme)

        # 호텔 고객평점
        if work_gbn['guest']:
            hotelGuest = pp.parserHotelGuest(property_data)
            hotelGuests.append(hotelGuest)

        # 호텔상세설명
        if work_gbn['ht_desc']:
            hotelDesc = pp.parserHotelDesc(property_data)
            hotelDescs.append(hotelDesc)

        # 호텔부대시설정보
        if work_gbn['ht_attrs']:
            temps = pp.parserHotelAttr(property_data)
            for hattr in temps:
                hotelAttrs.append(hattr)

        # 호텔편의시설
        if work_gbn['ht_amens']:
            temps = pp.parserHotelAmen(property_data)
            for hameni in temps:
                hotelAmens.append(hameni)

        # 호텔 이미지정보
        if work_gbn['ht_images']:
            temps = pp.parserHotelImage(property_data)
            for himg in temps:
                hotelImages.append(himg)

        # 객실기본정보
        if work_gbn['room']:
            temps = pp.parserRoomBase(property_data)
            for rdesc in temps:
                roomBases.append(rdesc)

        # 객실편의시설 정보
        if work_gbn['rm_amens']:
            temps = pp.parserRoomAmeni(property_data)
            for rameni in temps:
                roomAmenis.append(rameni)

        # 객실이미지정보
        if work_gbn['rm_images']:
            temps = pp.parserRoomImage(property_data)
            for rimg in temps:
                roomImages.append(rimg)

        count += 1

    print("==============================================================")
    print("language                   : ", language)
    print("==============================================================")
    if work_gbn['hotel']:
        print("hotel count                : ", len(hotels))
    if work_gbn['themes']:
        print("hotel Theme count          : ", len(themes))
    if work_gbn['guest']:
        print("hotel Guest ratings count  : ", len(hotelGuests))
    if work_gbn['ht_desc']:
        print("hotel Description count    : ", len(hotelDescs))
    if work_gbn['ht_attrs']:
        print("hotel Attributies count    : ", len(hotelAttrs))
    if work_gbn['ht_amens']:
        print("hotel Amenities count      : ", len(hotelAmens))
    if work_gbn['ht_images']:
        print("hotel Image count          : ", len(hotelImages))
    if work_gbn['room']:
        print("hotel Room Base count      : ", len(roomBases))
    if work_gbn['rm_amens']:
        print("hotel Room Amenities count : ", len(roomAmenis))
    if work_gbn['rm_images']:
        print("hotel Room Image count     : ", len(roomImages))
    print("==============================================================")

    if work_gbn['hotel']:
        print('>>> hotel information')
        execData = {'language': language, 'datas': hotels}
        result = ed.executeHotel(execData, conn, cursor)
        ers.summary(result)

    if work_gbn['themes']:
        print('>>> hotel theme information')
        execData = {'language': language, 'datas': themes}
        result = ed.executeHotelTheme(execData, conn, cursor)
        ers.summary(result)

    if work_gbn['guest']:
        print('>>> hotel guest ratings')
        execData = {'language': language, 'datas': hotelGuests}
        result = ed.executeHotelGuest(execData, conn, cursor)
        ers.summary(result)

    if work_gbn['ht_desc']:
        print('>>> hotel description')
        execData = {'language': language, 'datas': hotelDescs}
        result = ed.executeHotelDesc(execData, conn, cursor)
        ers.summary(result)

    if work_gbn['ht_images']:
        print('>>> hotel images')
        execData = {'language': language, 'datas': hotelImages}
        result = ed.executeHotelImage(execData, conn, cursor)
        ers.summary(result)

    if work_gbn['ht_attrs']:
        print('>>> hotel attribbutes')
        execData = {'language': language, 'datas': hotelAttrs}
        result = ed.executeHotelAttr(execData, conn, cursor)
        ers.summary(result)

    if work_gbn['ht_amens']:
        print('>>> hotel amenities')
        execData = {'language': language, 'datas': hotelAmens}
        result = ed.executeHotelAmen(execData, conn, cursor)
        ers.summary(result)

    if work_gbn['room']:
        print('>>> room base')
        execData = {'language': language, 'datas': roomBases}
        result = ed.executeRoomBase(execData, conn, cursor)
        ers.summary(result)

    if work_gbn['rm_amens']:
        print('>>> room amenities')
        execData = {'language': language, 'datas': roomAmenis}
        result = ed.executeRoomAmeni(execData, conn, cursor)
        ers.summary(result)

    if work_gbn['rm_images']:
        print('>>> room images')
        execData = {'language': language, 'datas': roomImages}
        result = ed.executeRoomImage(execData, conn, cursor)
        ers.summary(result)

    cursor.close()
    conn.close()

    return count


def updateContent(param):
    print(">>> supplier.ean.update_context_overall.updateContent start...")

    language = param['language']
    linked = param['linked']

    url = ean.base + 'properties/content'

    # EAN API 호출
    if linked == '':
        print(">>> call to rapid 2.4 api...")
        response = requests.get(url, headers=ean.headers(), params=param)
    else:
        response = requests.get(linked, headers=ean.headers())

    print('Rapid status code : ' + str(response.status_code))

    moreLink = ''
    more = ''
    count = 0
    if response.status_code == 200:

        if response.headers.get('Link') is None:
            more = ''
            moreLink = ''
        else:
            more = response.headers.get('Link')
            more = more.split('<')[1]
            more = more.split('>')[0]
            moreLink = more

        count = 0
        property_json = json.loads(response.content)
        keys = property_json.keys()
        if not bool(keys):
            data = {
                'status': 'empty data',
                'language': language,
                'exec count': count,
                'moreLink': moreLink
            }
            print(data['status'])
            print("finished...")
            return data
        else:
            print(">>> process execute start...")
            count = processExecute(property_json, param)

        data = {
            'status': 'scuccess',
            'language': language,
            'exec count': count,
            'moreLink': moreLink
        }
    else:
        print(response.text)
        data = json.loads(response.text)

    print("finished...")

    return data
