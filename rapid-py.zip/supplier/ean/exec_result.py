def summary(result):
    print(">> Added or Modified Summary [", result['exec'] + " ]")
    print("   -----------------------------------------------------------")
    print("   " + result['exec'] + " Error : ", result['error']['count'])
    if result['error']['count'] > 0:
        print("   -----------------------------------------------------------")
        errors = result['error']['errors']
        for data in errors:
            print(data)
    print("   ===========================================================")
