# ===========================================================================
# 파싱이 완료된 호텔콘텐츠를 입력받아 DB에 저장한다.
# ===========================================================================
import time
import pandas as pd
import common.utils as utils

# 호텔기본정보
def executeHotel(execData, conn, cursor):
    tCount = 0
    fCount = 0
    elist = list()

    entityName = 'ean_properties_en'
    if execData['language'] == 'ko-KR':
        entityName = 'ean_properties_ko'

    print(">>> " + entityName + " context update start...")

    for data in execData['datas']:
        property_nm = data['property_nm']
        addr = data['address']
        state_province_nm = data['state_province_nm']
        checkin_instructions = data['checkin_instructions']
        checkin_special_instructions = data['checkin_special_instructions']

        property_nm = property_nm.replace("'", "''")
        addr = addr.replace("'", "''")
        state_province_nm = state_province_nm.replace("'", "''")
        checkin_instructions = checkin_instructions.replace("'", "''")
        checkin_special_instructions = checkin_special_instructions.replace("'", "''")

        query = ("insert into " + entityName + " "
                 + "set "
                 + "property_id = '" + str(data['property_id']) + "',"
                 + "property_nm = '" + utils.qouteConvert(property_nm) + "',"
                 + "category_id = '" + str(data['category_id']) + "',"
                 + "category_nm = '" + data['category_nm'] + "',"
                 + "country_cd = '" + data['country_cd'] + "',"
                 + "city = '" + utils.qouteConvert(data['city']) + "',"
                 + "postal_cd = '" + str(data['postal_cd']) + "',"
                 + "address = '" + utils.qouteConvert(addr) + "',"
                 + "checkin_stime = '" + data['checkin_stime'] + "',"
                 + "checkin_etime = '" + data['checkin_etime'] + "',"
                 + "checkin_min_age = '" + str(data['checkin_min_age']) + "',"
                 + "checkin_instructions = '" + utils.qouteConvert(checkin_instructions) + "',"
                 + "checkin_special_instructions = '" + utils.qouteConvert(checkin_special_instructions) + "',"
                 + "phone = '" + str(data['phone']) + "',"
                 + "fax = '" + str(data['fax']) + "',"
                 + "lat = '" + str(data['lat']) + "',"
                 + "lon = '" + str(data['lon']) + "',"
                 + "rank = '" + str(data['rank']) + "',"
                 + "rating_type = '" + data['rating_type'] + "',"
                 + "rating_val = '" + str(data['rating_val']) + "',"
                 + "state_province_cd = '" + data['state_province_cd'] + "',"
                 + "state_province_nm = '" + utils.qouteConvert(state_province_nm) + "'"
                 + "on duplicate key update "
                 + "property_nm = '" + property_nm + "',"
                 + "category_id = '" + str(data['category_id']) + "',"
                 + "category_nm = '" + data['category_nm'] + "',"
                 + "country_cd = '" + data['country_cd'] + "',"
                 + "city = '" + utils.qouteConvert(data['city']) + "',"
                 + "postal_cd = '" + str(data['postal_cd']) + "',"
                 + "address = '" + utils.qouteConvert(addr) + "',"
                 + "checkin_stime = '" + data['checkin_stime'] + "',"
                 + "checkin_etime = '" + data['checkin_etime'] + "',"
                 + "checkin_min_age = '" + str(data['checkin_min_age']) + "',"
                 + "checkin_instructions = '" + utils.qouteConvert(checkin_instructions) + "',"
                 + "checkin_special_instructions = '" + utils.qouteConvert(checkin_special_instructions) + "',"
                 + "phone = '" + str(data['phone']) + "',"
                 + "fax = '" + str(data['fax']) + "',"
                 + "lat = '" + str(data['lat']) + "',"
                 + "lon = '" + str(data['lon']) + "',"
                 + "rank = '" + str(data['rank']) + "',"
                 + "rating_type = '" + data['rating_type'] + "',"
                 + "rating_val = '" + str(data['rating_val']) + "',"
                 + "state_province_cd = '" + data['state_province_cd'] + "',"
                 + "state_province_nm = '" + utils.qouteConvert(state_province_nm) + "'"
                 )
        # print(str(data['property_id']) + " : " + data['property_nm'])
        try:
            cursor.execute(query)
            conn.commit()
            tCount += 1
        except Exception as e:
            conn.rollback()
            fCount += 1
            elist.append(query)
    result = {
        'exec': 'property_base',
        'success': tCount,
        'entityName': entityName,
        'error': {
            'count': fCount,
            'errors': elist
        }

    }
    return result


# 호텔 테마정보
def executeHotelTheme(execData, conn, cursor):
    tCount = 0
    fCount = 0
    elist = list()

    entityName = 'ean_property_theme_en'
    if execData['language'] == 'ko-KR':
        entityName = 'ean_property_theme_ko'

    print(">>> " + entityName + " context update start...")

    for data in execData['datas']:
        query = ("INSERT INTO " + entityName + " SET "
                 + "property_id = '" + str(data['property_id']) + "',"
                 + "theme_id = '" + data['theme_id'] + "',"
                 + "theme_nm = '" + data['theme_nm'] + "' "
                 + "ON DUPLICATE KEY UPDATE "
                 + "theme_nm = '" + data['theme_nm'] + "'"
                 )

        try:
            cursor.execute(query)
            conn.commit()
            tCount += 1
        except Exception as e:
            conn.rollback()
            fCount += 1
            elist.append(query)

    result = {
        'exec': 'property_theme',
        'success': tCount,
        'entityName': entityName,
        'error': {
            'count': fCount,
            'errors': elist
        }

    }
    return result


def executeHotelGuest(execData, conn, cursor):
    tCount = 0
    fCount = 0
    elist = list()

    entityName = 'ean_property_guest'

    print(">>> " + entityName + " context update start...")

    for data in execData['datas']:
        query = ("INSERT INTO " + entityName + " SET "
                 + "property_id = '" + data['property_id'] + "',"
                 + "count = '" + data['count'] + "',"
                 + "overall = '" + data['overall'] + "',"
                 + "cleanliness = '" + data['cleanliness'] + "',"
                 + "service = '" + data['service'] + "',"
                 + "comfort = '" + data['comfort'] + "',"
                 + "g_condition = '" + data['condition'] + "',"
                 + "location = '" + data['location'] + "',"
                 + "neighborhood = '" + data['neighborhood'] + "',"
                 + "quality = '" + data['quality'] + "',"
                 + "value = '" + data['value'] + "',"
                 + "amenities = '" + data['amenities'] + "',"
                 + "recom_percent = '" + data['recom_percent'] + "' "
                 + "ON DUPLICATE KEY UPDATE "
                 + "count = '" + data['count'] + "',"
                 + "overall = '" + data['overall'] + "',"
                 + "cleanliness = '" + data['cleanliness'] + "',"
                 + "service = '" + data['service'] + "',"
                 + "comfort = '" + data['comfort'] + "',"
                 + "g_condition = '" + data['condition'] + "',"
                 + "location = '" + data['location'] + "',"
                 + "neighborhood = '" + data['neighborhood'] + "',"
                 + "quality = '" + data['quality'] + "',"
                 + "value = '" + data['value'] + "',"
                 + "amenities = '" + data['amenities'] + "',"
                 + "recom_percent = '" + data['recom_percent'] + "'"
                 )
        try:
            cursor.execute(query)
            conn.commit()
            tCount += 1
        except Exception as e:
            conn.rollback()
            fCount += 1
            elist.append(query)

    result = {
        'exec': 'property_guest',
        'success': tCount,
        'entityName': entityName,
        'error': {
            'count': fCount,
            'errors': elist
        }

    }
    return result


def executeHotelDesc(execData, conn, cursor):
    tCount = 0
    fCount = 0
    elist = list()

    entityName = 'ean_property_descs_en'
    if execData['language'] == 'ko-KR':
        entityName = 'ean_property_descs_ko'

    print(">>> " + entityName + " context update start...")

    for data in execData['datas']:
        query = ("INSERT INTO " + entityName + " SET "
                     + "property_id = '" + str(data['property_id']) + "',"
                     + "headline = '" + utils.qouteConvert(data['headline']) + "',"
                     + "amenities = '" + utils.qouteConvert(data['amenities']) + "',"
                     + "dining = '" + utils.qouteConvert(data['dining']) + "',"
                     + "business_amenities = '" + utils.qouteConvert(data['business_amenities']) + "',"
                     + "rooms = '" + utils.qouteConvert(data['rooms']) + "',"
                     + "attractions = '" + utils.qouteConvert(data['attractions']) + "',"
                     + "renovations = '" + utils.qouteConvert(data['renovations']) + "',"
                     + "know_before_you_go = '" + utils.qouteConvert(data['know_before_you_go']) + "',"
                     + "fees_mandatory = '" + utils.qouteConvert(data['fees_mandatory']) + "',"
                     + "fees_option = '" + utils.qouteConvert(data['fees_option']) + "' "
                 + "ON DUPLICATE KEY UPDATE "
                     + "headline = '" + utils.qouteConvert(data['headline']) + "',"
                     + "amenities = '" + utils.qouteConvert(data['amenities']) + "',"
                     + "dining = '" + utils.qouteConvert(data['dining']) + "',"
                     + "business_amenities = '" + utils.qouteConvert(data['business_amenities']) + "',"
                     + "rooms = '" + utils.qouteConvert(data['rooms']) + "',"
                     + "attractions = '" + utils.qouteConvert(data['attractions']) + "',"
                     + "renovations = '" + utils.qouteConvert(data['renovations']) + "',"
                     + "know_before_you_go = '" + utils.qouteConvert(data['know_before_you_go']) + "',"
                     + "fees_mandatory = '" + utils.qouteConvert(data['fees_mandatory']) + "',"
                     + "fees_option = '" + utils.qouteConvert(data['fees_option']) + "'"
                 )

        try:
            cursor.execute(query)
            conn.commit()
            tCount += 1
        except Exception as e:
            conn.rollback()
            fCount += 1
            elist.append(query)

    result = {
        'exec': 'property_desc',
        'success': tCount,
        'entityName': entityName,
        'error': {
            'count': fCount,
            'errors': elist
        }

    }
    return result


# 호텔 부대시설 정보
def executeHotelAttr(execData, conn, cursor):
    tCount = 0
    fCount = 0
    elist = list()

    entityName = 'ean_property_attributes_en'
    if execData['language'] == 'ko-KR':
        entityName = 'ean_property_attributes_ko'

    print(">>> " + entityName + " context update start...")

    for data in execData['datas']:
        query = ("INSERT INTO " + entityName + " SET "
                 + "property_id = '" + str(data['property_id']) + "',"
                 + "attribute_gbn = '" + data['attribute_gbn'] + "',"
                 + "attribute_id = '" + data['attribute_id'] + "',"
                 + "attribute_nm = '" + data['attribute_nm'] + "',"
                 + "attribute_val = '" + data['attribute_val'] + "' "
                 + "ON DUPLICATE KEY UPDATE "
                 + "attribute_nm = '" + data['attribute_nm'] + "',"
                 + "attribute_val = '" + data['attribute_val'] + "'"
                 )

        try:
            cursor.execute(query)
            conn.commit()
            tCount += 1
        except Exception as e:
            conn.rollback()
            fCount += 1
            elist.append(query)

    result = {
        'exec': 'property_attributies',
        'success': tCount,
        'error': {
            'count': fCount,
            'errors': elist
        }

    }
    return result


# 호텔 편의시설 정보
def executeHotelAmen(execData, conn, cursor):
    tCount = 0
    fCount = 0
    elist = list()

    entityName = 'ean_property_amenity_en'
    if execData['language'] == 'ko-KR':
        entityName = 'ean_property_amenity_ko'

    print(">>> " + entityName + " context update start...")

    for data in execData['datas']:
        query = ("INSERT INTO " + entityName + " SET "
                 + "property_id = '" + str(data['property_id']) + "',"
                 + "amenity_id = '" + data['amenity_id'] + "',"
                 + "amenity_nm = '" + data['amenity_nm'] + "',"
                 + "amenity_val = '" + data['amenity_val'] + "' "
                 + "ON DUPLICATE KEY UPDATE "
                 + "amenity_nm = '" + data['amenity_nm'] + "',"
                 + "amenity_val = '" + data['amenity_val'] + "'"
                 )

        try:
            cursor.execute(query)
            conn.commit()
            tCount += 1
        except Exception as e:
            conn.rollback()
            fCount += 1
            elist.append(query)

    result = {
        'exec': 'property_amenities',
        'success': tCount,
        'entityName': entityName,
        'error': {
            'count': fCount,
            'errors': elist
        }

    }
    return result


# 호텔 이미지 정보
def executeHotelImage(execData, conn, cursor):
    tCount = 0
    fCount = 0
    elist = list()

    if len(execData['datas']) > 0:
        old_property_id = ""

        print(">>> ean_property_images context update start...")

        for data in execData['datas']:

            if str(data['property_id']) != old_property_id:
                delq = "DELETE FROM ean_property_images WHERE property_id = '" + str(data['property_id']) + "'"
                cursor.execute(delq)
                conn.commit()

            query = (
                    "INSERT INTO ean_property_images (property_id, img_seq, category_id, hero, href_70, href_350, href_1000) VALUES ("
                    + "'" + str(data['property_id']) + "',"
                    + "'" + str(data['img_seq']) + "',"
                    + "'" + str(data['category_id']) + "',"
                    + "'" + data['hero'] + "',"
                    + "'" + data['href_70'] + "',"
                    + "'" + data['href_350'] + "',"
                    + "'" + data['href_1000'] + "')"
            )

            try:
                cursor.execute(query)
                conn.commit()
                tCount += 1
            except Exception as e:
                conn.rollback()
                fCount += 1
                elist.append(query)
            finally:
                old_property_id = str(data['property_id'])
        result = {
            'exec': 'property_images',
            'success': tCount,
            'entityName': 'ean_property_images',
            'error': {
                'count': fCount,
                'errors': elist
            }

        }
    return result


# 객실 기본정보
def executeRoomBase(execData, conn, cursor):
    tCount = 0
    fCount = 0
    elist = list()

    entityName = 'ean_room_en'
    if execData['language'] == 'ko-KR':
        entityName = 'ean_room_ko'

    print(">>> " + entityName + " context update start...")

    for data in execData['datas']:

        try:
            query = ("INSERT INTO " + entityName + " SET "
                     + "property_id = '" + str(data['property_id']) + "',"
                     + "room_id = '" + data['room_id'] + "',"
                     + "room_desc = '" + data['desc'] + "' "
                     + "ON DUPLICATE KEY UPDATE "
                     + "room_desc = '" + data['desc'] + "'"
                     )
            cursor.execute(query)
            conn.commit()
            tCount += 1
        except Exception as e:
            conn.rollback()
            fCount += 1
            elist.append(query)

    result = {
        'exec': 'room_base',
        'success': tCount,
        'entityName': entityName,
        'error': {
            'count': fCount,
            'errors': elist
        }

    }
    return result


# 객실 편의시설
def executeRoomAmeni(execData, conn, cursor):
    tCount = 0
    fCount = 0
    elist = list()

    entityName = 'ean_room_amenity_en'
    if execData['language'] == 'ko-KR':
        entityName = 'ean_room_amenity_ko'

    print(">>> " + entityName + " context update start...")

    for data in execData['datas']:
        query = ("INSERT INTO " + entityName + " SET "
                 + "property_id = '" + str(data['property_id']) + "',"
                 + "room_id = '" + data['room_id'] + "',"
                 + "amenity_id = '" + data['amenity_id'] + "',"
                 + "amenity_nm = '" + data['amenity_nm'] + "',"
                 + "amenity_val = '" + data['amenity_val'] + "' "
                 + "ON DUPLICATE KEY UPDATE "
                 + "amenity_nm = '" + data['amenity_nm'] + "',"
                 + "amenity_val = '" + data['amenity_val'] + "'"
                 )

        try:
            cursor.execute(query)
            conn.commit()
            tCount += 1
        except Exception as e:
            conn.rollback()
            fCount += 1
            elist.append(query)

    result = {
        'exec': 'room_aminities',
        'success': tCount,
        'entityName': entityName,
        'error': {
            'count': fCount,
            'errors': elist
        }

    }
    return result


# 객실 이미지
def executeRoomImage(execData, conn, cursor):
    tCount = 0
    fCount = 0
    elist = list()

    old_property_id = ""

    print(">>> ean_room_images context update start...")

    for data in execData['datas']:

        if str(data['property_id']) != old_property_id:
            delq = "DELETE FROM ean_room_images WHERE property_id = '" + str(data['property_id']) + "'"
            cursor.execute(delq)
            conn.commit()

        query = (
                "INSERT INTO ean_room_images (property_id, room_id, img_seq, category_id, hero, href_70, href_200, href_350, href_1000) VALUES ("
                + "'" + str(data['property_id']) + "',"
                + "'" + data['room_id'] + "',"
                + "'" + str(data['img_seq']) + "',"
                + "'" + str(data['category_id']) + "',"
                + "'" + data['hero'] + "',"
                + "'" + data['href_70'] + "',"
                + "'" + data['href_200'] + "',"
                + "'" + data['href_350'] + "',"
                + "'" + data['href_1000'] + "')"
        )

        try:
            cursor.execute(query)
            conn.commit()
            tCount += 1
        except Exception as e:
            conn.rollback()
            fCount += 1
            elist.append(query)
        finally:
            old_property_id = str(data['property_id'])

    result = {
        'exec': 'room_images',
        'success': tCount,
        'entityName': 'ean_room_images',
        'error': {
            'count': fCount,
            'errors': elist
        }

    }
    return result
