# eanauth

import time
import hashlib

key = "28n28oiguc7e06g9uinf06nn2"
secret = "5l45gt9oi2n1g"

base = "https://test.ean.com/2.4/"


def signature():
    timestamp = int(time.time())
    signature = hashlib.sha512(str(key + secret + str(timestamp)).encode('utf-8')).hexdigest()
    return "EAN ApiKey=" + key + ",Signature=" + signature + ",timestamp=" + str(timestamp)


def headers():
    return {
        'Accept': 'application/json',
        'User-Agent': 'my-app/0.0.1',
        'Customer-Ip': '5.5.5.5',
        'Accept-Encoding': 'gzip',
        'Authorization': signature()
    }
