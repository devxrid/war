from logging import handlers
import logging
from flask import Flask, jsonify, request
from flask_restful import Resource, Api
from flask_cors import CORS
import json
import common.utils as utils
import supplier.ean.update_context_overall as overall

# ====================================================================================================================
# log settings
# ====================================================================================================================
slogFormatter = logging.Formatter('%(asctime)s,%(message)s')
# handler settings
slogHandler = handlers.TimedRotatingFileHandler(filename='./log/ean_static.log', when='midnight', interval=1,
                                                encoding='utf-8')

slogHandler.setFormatter(slogFormatter)
slogHandler.suffix = "%Y%m%d"
# logger set
slog = logging.getLogger()
slog.setLevel(logging.INFO)
slog.addHandler(slogHandler)
# ====================================================================================================================


app = Flask(__name__)
CORS(app)
api = Api(app)


# 익스피디아 콘텐츠 업데이트
class ean_contents_update(Resource):
    def post(self):

        hotel = False
        themes = False
        guest = False
        ht_desc = False
        ht_images = False
        ht_attrs = False
        ht_amens = False
        room = False
        rm_amens = False
        rm_images = False

        try:
            param_data = request.get_json(force=True)
            items = param_data['items']

            if len(items) > 0:
                for item in items:
                    if item['id'] == 'hotel':
                        hotel = True
                    elif item['id'] == 'themes':
                        themes = True
                    elif item['id'] == 'guest':
                        guest = True
                    elif item['id'] == 'ht_desc':
                        ht_desc = True
                    elif item['id'] == 'ht_images':
                        ht_images = True
                    elif item['id'] == 'ht_attrs':
                        ht_attrs = True
                    elif item['id'] == 'ht_amens':
                        ht_amens = True
                    elif item['id'] == 'room':
                        room = True
                    elif item['id'] == 'rm_amens':
                        rm_amens = True
                    elif item['id'] == 'rm_images':
                        rm_images = True

            params = {
                'language': param_data['language'],
                'hotel': hotel,
                'themes': themes,
                'guest': guest,
                'ht_desc': ht_desc,
                'ht_images': ht_images,
                'ht_attrs': ht_attrs,
                'ht_amens': ht_amens,
                'room': room,
                'rm_amens': rm_amens,
                'rm_images': rm_images,
                'linked': ''
            }

            if param_data['property_ids'] != '':
                params['property_ids'] = param_data['property_ids']

            if param_data['date_updated_start'] != '':
                params['date_updated_start'] = param_data['date_updated_start']

            more_result = True
            linked = ''
            result = {

            }

            slog.info(params)

            while more_result:
                result = overall.updateContent(params)
                if len(result['moreLink']) == 0:
                    more_result = False
                else:
                    more_result = True
                    print("next link: ", result['moreLink'])
                    params['linked'] = result['moreLink']

            return params
        except Exception as e:
            print(e)
            return {
                'status': 'error',
                'error': str(e)
            }


# router

# EAN Static Data update
api.add_resource(ean_contents_update, '/ean/contents')

if __name__ == '__main__':
    root_logger = logging.getLogger()
    app.run(host='0.0.0.0', port='5000', debug=True)
